

/* this ALWAYS GENERATED file contains the proxy stub code */


 /* File created by MIDL compiler version 8.01.0622 */
/* at Mon Jan 18 19:14:07 2038
 */
/* Compiler settings for C:\Users\User\AppData\Local\Temp\Microsoft.SDKSamples.Kitchen.idl-b98a621c:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.01.0622 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#if !defined(_M_IA64) && !defined(_M_AMD64) && !defined(_ARM_)


#pragma warning( disable: 4049 )  /* more than 64k source lines */
#if _MSC_VER >= 1200
#pragma warning(push)
#endif

#pragma warning( disable: 4211 )  /* redefine extern to static */
#pragma warning( disable: 4232 )  /* dllimport identity*/
#pragma warning( disable: 4024 )  /* array to pointer mapping*/
#pragma warning( disable: 4152 )  /* function/data pointer conversion in expression */
#pragma warning( disable: 4100 ) /* unreferenced arguments in x86 call */

#pragma optimize("", off ) 

#define USE_STUBLESS_PROXY


/* verify that the <rpcproxy.h> version is high enough to compile this file*/
#ifndef __REDQ_RPCPROXY_H_VERSION__
#define __REQUIRED_RPCPROXY_H_VERSION__ 475
#endif


#include "rpcproxy.h"
#ifndef __RPCPROXY_H_VERSION__
#error this stub requires an updated version of <rpcproxy.h>
#endif /* __RPCPROXY_H_VERSION__ */


#include "Microsoft.SDKSamples.Kitchen.h"

#define TYPE_FORMAT_STRING_SIZE   159                               
#define PROC_FORMAT_STRING_SIZE   343                               
#define EXPR_FORMAT_STRING_SIZE   1                                 
#define TRANSMIT_AS_TABLE_SIZE    0            
#define WIRE_MARSHAL_TABLE_SIZE   1            

typedef struct _Microsoft2ESDKSamples2EKitchen_MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } Microsoft2ESDKSamples2EKitchen_MIDL_TYPE_FORMAT_STRING;

typedef struct _Microsoft2ESDKSamples2EKitchen_MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } Microsoft2ESDKSamples2EKitchen_MIDL_PROC_FORMAT_STRING;

typedef struct _Microsoft2ESDKSamples2EKitchen_MIDL_EXPR_FORMAT_STRING
    {
    long          Pad;
    unsigned char  Format[ EXPR_FORMAT_STRING_SIZE ];
    } Microsoft2ESDKSamples2EKitchen_MIDL_EXPR_FORMAT_STRING;


static const RPC_SYNTAX_IDENTIFIER  _RpcTransferSyntax = 
{{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}};


extern const Microsoft2ESDKSamples2EKitchen_MIDL_TYPE_FORMAT_STRING Microsoft2ESDKSamples2EKitchen__MIDL_TypeFormatString;
extern const Microsoft2ESDKSamples2EKitchen_MIDL_PROC_FORMAT_STRING Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString;
extern const Microsoft2ESDKSamples2EKitchen_MIDL_EXPR_FORMAT_STRING Microsoft2ESDKSamples2EKitchen__MIDL_ExprFormatString;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO __FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO __FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory_ProxyInfo;


extern const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[ WIRE_MARSHAL_TABLE_SIZE ];

#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

#if !(TARGET_IS_NT50_OR_LATER)
#error You need Windows 2000 or later to run this stub because it uses these features:
#error   /robust command line switch.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will fail with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const Microsoft2ESDKSamples2EKitchen_MIDL_PROC_FORMAT_STRING Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString =
    {
        0,
        {

	/* Procedure get_Flavor */

			0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/*  2 */	NdrFcLong( 0x0 ),	/* 0 */
/*  6 */	NdrFcShort( 0x6 ),	/* 6 */
/*  8 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 10 */	NdrFcShort( 0x0 ),	/* 0 */
/* 12 */	NdrFcShort( 0x8 ),	/* 8 */
/* 14 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 16 */	0x8,		/* 8 */
			0x3,		/* Ext Flags:  new corr desc, clt corr check, */
/* 18 */	NdrFcShort( 0x1 ),	/* 1 */
/* 20 */	NdrFcShort( 0x0 ),	/* 0 */
/* 22 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter value */

/* 24 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 26 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 28 */	NdrFcShort( 0x20 ),	/* Type Offset=32 */

	/* Return value */

/* 30 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 32 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 34 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Volume */

/* 36 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 38 */	NdrFcLong( 0x0 ),	/* 0 */
/* 42 */	NdrFcShort( 0x6 ),	/* 6 */
/* 44 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 46 */	NdrFcShort( 0x0 ),	/* 0 */
/* 48 */	NdrFcShort( 0x2c ),	/* 44 */
/* 50 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 52 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 54 */	NdrFcShort( 0x0 ),	/* 0 */
/* 56 */	NdrFcShort( 0x0 ),	/* 0 */
/* 58 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter value */

/* 60 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 62 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 64 */	0xc,		/* FC_DOUBLE */
			0x0,		/* 0 */

	/* Return value */

/* 66 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 68 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 70 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Bread */

/* 72 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 74 */	NdrFcLong( 0x0 ),	/* 0 */
/* 78 */	NdrFcShort( 0x6 ),	/* 6 */
/* 80 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 82 */	NdrFcShort( 0x0 ),	/* 0 */
/* 84 */	NdrFcShort( 0x8 ),	/* 8 */
/* 86 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x2,		/* 2 */
/* 88 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 90 */	NdrFcShort( 0x0 ),	/* 0 */
/* 92 */	NdrFcShort( 0x0 ),	/* 0 */
/* 94 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter value */

/* 96 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 98 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 100 */	NdrFcShort( 0x2e ),	/* Type Offset=46 */

	/* Return value */

/* 102 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 104 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 106 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Invoke */

/* 108 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 110 */	NdrFcLong( 0x0 ),	/* 0 */
/* 114 */	NdrFcShort( 0x3 ),	/* 3 */
/* 116 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 118 */	NdrFcShort( 0x0 ),	/* 0 */
/* 120 */	NdrFcShort( 0x8 ),	/* 8 */
/* 122 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 124 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 126 */	NdrFcShort( 0x0 ),	/* 0 */
/* 128 */	NdrFcShort( 0x0 ),	/* 0 */
/* 130 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter sender */

/* 132 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 134 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 136 */	NdrFcShort( 0x44 ),	/* Type Offset=68 */

	/* Parameter e */

/* 138 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 140 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 142 */	NdrFcShort( 0x56 ),	/* Type Offset=86 */

	/* Return value */

/* 144 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 146 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 148 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure ConfigurePreheatTemperature */

/* 150 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 152 */	NdrFcLong( 0x0 ),	/* 0 */
/* 156 */	NdrFcShort( 0x6 ),	/* 6 */
/* 158 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 160 */	NdrFcShort( 0x8 ),	/* 8 */
/* 162 */	NdrFcShort( 0x8 ),	/* 8 */
/* 164 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 166 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 168 */	NdrFcShort( 0x0 ),	/* 0 */
/* 170 */	NdrFcShort( 0x0 ),	/* 0 */
/* 172 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter temperature */

/* 174 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 176 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 178 */	0xe,		/* FC_ENUM32 */
			0x0,		/* 0 */

	/* Return value */

/* 180 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 182 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 184 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure BakeBread */

/* 186 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 188 */	NdrFcLong( 0x0 ),	/* 0 */
/* 192 */	NdrFcShort( 0x7 ),	/* 7 */
/* 194 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 196 */	NdrFcShort( 0x0 ),	/* 0 */
/* 198 */	NdrFcShort( 0x8 ),	/* 8 */
/* 200 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x2,		/* 2 */
/* 202 */	0x8,		/* 8 */
			0x5,		/* Ext Flags:  new corr desc, srv corr check, */
/* 204 */	NdrFcShort( 0x0 ),	/* 0 */
/* 206 */	NdrFcShort( 0x1 ),	/* 1 */
/* 208 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter flavor */

/* 210 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 212 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 214 */	NdrFcShort( 0x6c ),	/* Type Offset=108 */

	/* Return value */

/* 216 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 218 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 220 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure add_BreadBaked */

/* 222 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 224 */	NdrFcLong( 0x0 ),	/* 0 */
/* 228 */	NdrFcShort( 0x8 ),	/* 8 */
/* 230 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 232 */	NdrFcShort( 0x0 ),	/* 0 */
/* 234 */	NdrFcShort( 0x34 ),	/* 52 */
/* 236 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x3,		/* 3 */
/* 238 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 240 */	NdrFcShort( 0x0 ),	/* 0 */
/* 242 */	NdrFcShort( 0x0 ),	/* 0 */
/* 244 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter handler */

/* 246 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 248 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 250 */	NdrFcShort( 0x76 ),	/* Type Offset=118 */

	/* Parameter token */

/* 252 */	NdrFcShort( 0x2112 ),	/* Flags:  must free, out, simple ref, srv alloc size=8 */
/* 254 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 256 */	NdrFcShort( 0x8c ),	/* Type Offset=140 */

	/* Return value */

/* 258 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 260 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 262 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure remove_BreadBaked */

/* 264 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 266 */	NdrFcLong( 0x0 ),	/* 0 */
/* 270 */	NdrFcShort( 0x9 ),	/* 9 */
/* 272 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 274 */	NdrFcShort( 0x18 ),	/* 24 */
/* 276 */	NdrFcShort( 0x8 ),	/* 8 */
/* 278 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x2,		/* 2 */
/* 280 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 282 */	NdrFcShort( 0x0 ),	/* 0 */
/* 284 */	NdrFcShort( 0x0 ),	/* 0 */
/* 286 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter token */

/* 288 */	NdrFcShort( 0x8a ),	/* Flags:  must free, in, by val, */
/* 290 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 292 */	NdrFcShort( 0x8c ),	/* Type Offset=140 */

	/* Return value */

/* 294 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 296 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 298 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure CreateOven */

/* 300 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 302 */	NdrFcLong( 0x0 ),	/* 0 */
/* 306 */	NdrFcShort( 0x6 ),	/* 6 */
/* 308 */	NdrFcShort( 0x24 ),	/* x86 Stack size/offset = 36 */
/* 310 */	NdrFcShort( 0x28 ),	/* 40 */
/* 312 */	NdrFcShort( 0x8 ),	/* 8 */
/* 314 */	0x45,		/* Oi2 Flags:  srv must size, has return, has ext, */
			0x3,		/* 3 */
/* 316 */	0x8,		/* 8 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 318 */	NdrFcShort( 0x0 ),	/* 0 */
/* 320 */	NdrFcShort( 0x0 ),	/* 0 */
/* 322 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter dimensions */

/* 324 */	NdrFcShort( 0x8a ),	/* Flags:  must free, in, by val, */
/* 326 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 328 */	NdrFcShort( 0x92 ),	/* Type Offset=146 */

	/* Parameter result */

/* 330 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 332 */	NdrFcShort( 0x1c ),	/* x86 Stack size/offset = 28 */
/* 334 */	NdrFcShort( 0x9a ),	/* Type Offset=154 */

	/* Return value */

/* 336 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 338 */	NdrFcShort( 0x20 ),	/* x86 Stack size/offset = 32 */
/* 340 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

			0x0
        }
    };

static const Microsoft2ESDKSamples2EKitchen_MIDL_TYPE_FORMAT_STRING Microsoft2ESDKSamples2EKitchen__MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */
/*  2 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/*  4 */	NdrFcShort( 0x1c ),	/* Offset= 28 (32) */
/*  6 */	
			0x13, 0x0,	/* FC_OP */
/*  8 */	NdrFcShort( 0xe ),	/* Offset= 14 (22) */
/* 10 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 12 */	NdrFcShort( 0x2 ),	/* 2 */
/* 14 */	0x9,		/* Corr desc: FC_ULONG */
			0x0,		/*  */
/* 16 */	NdrFcShort( 0xfffc ),	/* -4 */
/* 18 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 20 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 22 */	
			0x17,		/* FC_CSTRUCT */
			0x3,		/* 3 */
/* 24 */	NdrFcShort( 0x8 ),	/* 8 */
/* 26 */	NdrFcShort( 0xfff0 ),	/* Offset= -16 (10) */
/* 28 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 30 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 32 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 34 */	NdrFcShort( 0x0 ),	/* 0 */
/* 36 */	NdrFcShort( 0x4 ),	/* 4 */
/* 38 */	NdrFcShort( 0x0 ),	/* 0 */
/* 40 */	NdrFcShort( 0xffde ),	/* Offset= -34 (6) */
/* 42 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/* 44 */	0xc,		/* FC_DOUBLE */
			0x5c,		/* FC_PAD */
/* 46 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 48 */	NdrFcShort( 0x2 ),	/* Offset= 2 (50) */
/* 50 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 52 */	NdrFcLong( 0xf13ea3d5 ),	/* -247553067 */
/* 56 */	NdrFcShort( 0x7b24 ),	/* 31524 */
/* 58 */	NdrFcShort( 0x4cde ),	/* 19678 */
/* 60 */	0x9e,		/* 158 */
			0x5f,		/* 95 */
/* 62 */	0x57,		/* 87 */
			0xaf,		/* 175 */
/* 64 */	0x30,		/* 48 */
			0xf0,		/* 240 */
/* 66 */	0x73,		/* 115 */
			0x3c,		/* 60 */
/* 68 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 70 */	NdrFcLong( 0x6a112353 ),	/* 1779508051 */
/* 74 */	NdrFcShort( 0x4f87 ),	/* 20359 */
/* 76 */	NdrFcShort( 0x4460 ),	/* 17504 */
/* 78 */	0xa9,		/* 169 */
			0x8,		/* 8 */
/* 80 */	0x29,		/* 41 */
			0x44,		/* 68 */
/* 82 */	0xe9,		/* 233 */
			0x26,		/* 38 */
/* 84 */	0x86,		/* 134 */
			0xf3,		/* 243 */
/* 86 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 88 */	NdrFcLong( 0x699b1394 ),	/* 1771770772 */
/* 92 */	NdrFcShort( 0x3ceb ),	/* 15595 */
/* 94 */	NdrFcShort( 0x4a14 ),	/* 18964 */
/* 96 */	0xae,		/* 174 */
			0x23,		/* 35 */
/* 98 */	0xef,		/* 239 */
			0xec,		/* 236 */
/* 100 */	0x51,		/* 81 */
			0x8b,		/* 139 */
/* 102 */	0x8,		/* 8 */
			0x8b,		/* 139 */
/* 104 */	
			0x12, 0x0,	/* FC_UP */
/* 106 */	NdrFcShort( 0xffac ),	/* Offset= -84 (22) */
/* 108 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 110 */	NdrFcShort( 0x0 ),	/* 0 */
/* 112 */	NdrFcShort( 0x4 ),	/* 4 */
/* 114 */	NdrFcShort( 0x0 ),	/* 0 */
/* 116 */	NdrFcShort( 0xfff4 ),	/* Offset= -12 (104) */
/* 118 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 120 */	NdrFcLong( 0x6582b851 ),	/* 1703065681 */
/* 124 */	NdrFcShort( 0x18cc ),	/* 6348 */
/* 126 */	NdrFcShort( 0x5835 ),	/* 22581 */
/* 128 */	0x8c,		/* 140 */
			0x50,		/* 80 */
/* 130 */	0xd8,		/* 216 */
			0x96,		/* 150 */
/* 132 */	0xee,		/* 238 */
			0xdd,		/* 221 */
/* 134 */	0xa3,		/* 163 */
			0x0,		/* 0 */
/* 136 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 138 */	NdrFcShort( 0x2 ),	/* Offset= 2 (140) */
/* 140 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 142 */	NdrFcShort( 0x8 ),	/* 8 */
/* 144 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 146 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 148 */	NdrFcShort( 0x18 ),	/* 24 */
/* 150 */	0xc,		/* FC_DOUBLE */
			0xc,		/* FC_DOUBLE */
/* 152 */	0xc,		/* FC_DOUBLE */
			0x5b,		/* FC_END */
/* 154 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 156 */	NdrFcShort( 0xffa8 ),	/* Offset= -88 (68) */

			0x0
        }
    };

static const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[ WIRE_MARSHAL_TABLE_SIZE ] = 
        {
            
            {
            HSTRING_UserSize
            ,HSTRING_UserMarshal
            ,HSTRING_UserUnmarshal
            ,HSTRING_UserFree
            }

        };



/* Standard interface: __MIDL_itf_Microsoft2ESDKSamples2EKitchen_0000_0000, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Standard interface: __MIDL_itf_Microsoft2ESDKSamples2EKitchen2Eidl_0000_0328, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Standard interface: __MIDL_itf_Microsoft2ESDKSamples2EKitchen_0000_0001, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IInspectable, ver. 0.0,
   GUID={0xAF86E2E0,0xB12D,0x4c6a,{0x9C,0x5A,0xD7,0xAA,0x65,0x10,0x1E,0x90}} */


/* Object interface: __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread, ver. 0.0,
   GUID={0xF13EA3D5,0x7B24,0x4CDE,{0x9E,0x5F,0x57,0xAF,0x30,0xF0,0x73,0x3C}} */

#pragma code_seg(".orpc")
static const unsigned short __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread_ProxyInfo =
    {
    &Object_StubDesc,
    Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString.Format,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString.Format,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) ___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadProxyVtbl = 
{
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread_ProxyInfo,
    &IID___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* IInspectable::GetIids */ ,
    0 /* IInspectable::GetRuntimeClassName */ ,
    0 /* IInspectable::GetTrustLevel */ ,
    (void *) (INT_PTR) -1 /* __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread::get_Flavor */
};


static const PRPC_STUB_FUNCTION __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2
};

CInterfaceStubVtbl ___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadStubVtbl =
{
    &IID___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread_ServerInfo,
    7,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Standard interface: __MIDL_itf_Microsoft2ESDKSamples2EKitchen_0000_0002, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Object interface: __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance, ver. 0.0,
   GUID={0x332FD2F1,0x1C69,0x4C91,{0x94,0x9E,0x4B,0xB6,0x7A,0x85,0xBD,0xC5}} */

#pragma code_seg(".orpc")
static const unsigned short __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    36
    };

static const MIDL_STUBLESS_PROXY_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance_ProxyInfo =
    {
    &Object_StubDesc,
    Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString.Format,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString.Format,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) ___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIApplianceProxyVtbl = 
{
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance_ProxyInfo,
    &IID___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* IInspectable::GetIids */ ,
    0 /* IInspectable::GetRuntimeClassName */ ,
    0 /* IInspectable::GetTrustLevel */ ,
    (void *) (INT_PTR) -1 /* __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance::get_Volume */
};


static const PRPC_STUB_FUNCTION __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2
};

CInterfaceStubVtbl ___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIApplianceStubVtbl =
{
    &IID___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance_ServerInfo,
    7,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Standard interface: __MIDL_itf_Microsoft2ESDKSamples2EKitchen_0000_0003, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Object interface: __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs, ver. 0.0,
   GUID={0x699B1394,0x3CEB,0x4A14,{0xAE,0x23,0xEF,0xEC,0x51,0x8B,0x08,0x8B}} */

#pragma code_seg(".orpc")
static const unsigned short __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    72
    };

static const MIDL_STUBLESS_PROXY_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs_ProxyInfo =
    {
    &Object_StubDesc,
    Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString.Format,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString.Format,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) ___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgsProxyVtbl = 
{
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs_ProxyInfo,
    &IID___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* IInspectable::GetIids */ ,
    0 /* IInspectable::GetRuntimeClassName */ ,
    0 /* IInspectable::GetTrustLevel */ ,
    (void *) (INT_PTR) -1 /* __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs::get_Bread */
};


static const PRPC_STUB_FUNCTION __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2
};

CInterfaceStubVtbl ___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgsStubVtbl =
{
    &IID___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs_ServerInfo,
    7,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Standard interface: __MIDL_itf_Microsoft2ESDKSamples2EKitchen2Eidl_0000_0329, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Standard interface: __MIDL_itf_Microsoft2ESDKSamples2EKitchen_0000_0005, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Object interface: __FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs, ver. 0.0,
   GUID={0x6582b851,0x18cc,0x5835,{0x8c,0x50,0xd8,0x96,0xee,0xdd,0xa3,0x00}} */

#pragma code_seg(".orpc")
static const unsigned short __FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs_FormatStringOffsetTable[] =
    {
    108
    };

static const MIDL_STUBLESS_PROXY_INFO __FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs_ProxyInfo =
    {
    &Object_StubDesc,
    Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString.Format,
    &__FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO __FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString.Format,
    &__FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(4) ___FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgsProxyVtbl = 
{
    &__FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs_ProxyInfo,
    &IID___FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    (void *) (INT_PTR) -1 /* __FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs::Invoke */
};

const CInterfaceStubVtbl ___FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgsStubVtbl =
{
    &IID___FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs,
    &__FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs_ServerInfo,
    4,
    0, /* pure interpreted */
    CStdStubBuffer_METHODS
};


/* Standard interface: __MIDL_itf_Microsoft2ESDKSamples2EKitchen_0000_0006, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Object interface: __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven, ver. 0.0,
   GUID={0x6A112353,0x4F87,0x4460,{0xA9,0x08,0x29,0x44,0xE9,0x26,0x86,0xF3}} */

#pragma code_seg(".orpc")
static const unsigned short __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    150,
    186,
    222,
    264
    };

static const MIDL_STUBLESS_PROXY_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven_ProxyInfo =
    {
    &Object_StubDesc,
    Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString.Format,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString.Format,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(10) ___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenProxyVtbl = 
{
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven_ProxyInfo,
    &IID___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* IInspectable::GetIids */ ,
    0 /* IInspectable::GetRuntimeClassName */ ,
    0 /* IInspectable::GetTrustLevel */ ,
    (void *) (INT_PTR) -1 /* __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven::ConfigurePreheatTemperature */ ,
    (void *) (INT_PTR) -1 /* __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven::BakeBread */ ,
    (void *) (INT_PTR) -1 /* __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven::add_BreadBaked */ ,
    (void *) (INT_PTR) -1 /* __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven::remove_BreadBaked */
};


static const PRPC_STUB_FUNCTION __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl ___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenStubVtbl =
{
    &IID___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven_ServerInfo,
    10,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Standard interface: __MIDL_itf_Microsoft2ESDKSamples2EKitchen_0000_0007, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Object interface: __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory, ver. 0.0,
   GUID={0xF36C2A21,0xF4E3,0x4C39,{0x94,0xCE,0xEB,0x91,0x90,0xAF,0xDA,0xB3}} */

#pragma code_seg(".orpc")
static const unsigned short __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    300
    };

static const MIDL_STUBLESS_PROXY_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory_ProxyInfo =
    {
    &Object_StubDesc,
    Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString.Format,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    Microsoft2ESDKSamples2EKitchen__MIDL_ProcFormatString.Format,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) ___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactoryProxyVtbl = 
{
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory_ProxyInfo,
    &IID___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* IInspectable::GetIids */ ,
    0 /* IInspectable::GetRuntimeClassName */ ,
    0 /* IInspectable::GetTrustLevel */ ,
    (void *) (INT_PTR) -1 /* __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory::CreateOven */
};


static const PRPC_STUB_FUNCTION __x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2
};

CInterfaceStubVtbl ___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactoryStubVtbl =
{
    &IID___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory_ServerInfo,
    7,
    &__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Standard interface: __MIDL_itf_Microsoft2ESDKSamples2EKitchen_0000_0008, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    Microsoft2ESDKSamples2EKitchen__MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0x50002, /* Ndr library version */
    0,
    0x801026e, /* MIDL Version 8.1.622 */
    0,
    UserMarshalRoutines,
    0,  /* notify & notify_flag routine table */
    0x1, /* MIDL flag */
    0, /* cs routines */
    0,   /* proxy/server info */
    0
    };

const CInterfaceProxyVtbl * const _Microsoft2ESDKSamples2EKitchen_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactoryProxyVtbl,
    ( CInterfaceProxyVtbl *) &___FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgsProxyVtbl,
    ( CInterfaceProxyVtbl *) &___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenProxyVtbl,
    ( CInterfaceProxyVtbl *) &___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgsProxyVtbl,
    ( CInterfaceProxyVtbl *) &___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadProxyVtbl,
    ( CInterfaceProxyVtbl *) &___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIApplianceProxyVtbl,
    0
};

const CInterfaceStubVtbl * const _Microsoft2ESDKSamples2EKitchen_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactoryStubVtbl,
    ( CInterfaceStubVtbl *) &___FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgsStubVtbl,
    ( CInterfaceStubVtbl *) &___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenStubVtbl,
    ( CInterfaceStubVtbl *) &___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgsStubVtbl,
    ( CInterfaceStubVtbl *) &___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadStubVtbl,
    ( CInterfaceStubVtbl *) &___x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIApplianceStubVtbl,
    0
};

PCInterfaceName const _Microsoft2ESDKSamples2EKitchen_InterfaceNamesList[] = 
{
    "__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOvenFactory",
    "__FITypedEventHandler_2_Microsoft__CSDKSamples__CKitchen__COven_Microsoft__CSDKSamples__CKitchen__CBreadBakedEventArgs",
    "__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIOven",
    "__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBreadBakedEventArgs",
    "__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIBread",
    "__x_ABI_CMicrosoft_CSDKSamples_CKitchen_CIAppliance",
    0
};

const IID *  const _Microsoft2ESDKSamples2EKitchen_BaseIIDList[] = 
{
    &IID_IInspectable,
    0,
    &IID_IInspectable,
    &IID_IInspectable,
    &IID_IInspectable,
    &IID_IInspectable,
    0
};


#define _Microsoft2ESDKSamples2EKitchen_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _Microsoft2ESDKSamples2EKitchen, pIID, n)

int __stdcall _Microsoft2ESDKSamples2EKitchen_IID_Lookup( const IID * pIID, int * pIndex )
{
    IID_BS_LOOKUP_SETUP

    IID_BS_LOOKUP_INITIAL_TEST( _Microsoft2ESDKSamples2EKitchen, 6, 4 )
    IID_BS_LOOKUP_NEXT_TEST( _Microsoft2ESDKSamples2EKitchen, 2 )
    IID_BS_LOOKUP_NEXT_TEST( _Microsoft2ESDKSamples2EKitchen, 1 )
    IID_BS_LOOKUP_RETURN_RESULT( _Microsoft2ESDKSamples2EKitchen, 6, *pIndex )
    
}

const ExtendedProxyFileInfo Microsoft2ESDKSamples2EKitchen_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _Microsoft2ESDKSamples2EKitchen_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _Microsoft2ESDKSamples2EKitchen_StubVtblList,
    (const PCInterfaceName * ) & _Microsoft2ESDKSamples2EKitchen_InterfaceNamesList,
    (const IID ** ) & _Microsoft2ESDKSamples2EKitchen_BaseIIDList,
    & _Microsoft2ESDKSamples2EKitchen_IID_Lookup, 
    6,
    2,
    0, /* table of [async_uuid] interfaces */
    0, /* Filler1 */
    0, /* Filler2 */
    0  /* Filler3 */
};
#if _MSC_VER >= 1200
#pragma warning(pop)
#endif


#endif /* !defined(_M_IA64) && !defined(_M_AMD64) && !defined(_ARM_) */

